console.log("[debug] aikias.js start");

$( document ).ready(function() {

    console.log("[debug] aikias.js document ready");

    $( "#period" ).click(function() {
        console.log("[debug] aikias.js period click");

        $( "input.period" ).prop("disabled", !this.checked);
        $( "#time" ).prop("checked", !this.checked);
        $( "input.time" ).prop("disabled", this.checked);

    });

    $( "#time" ).click(function() {
        console.log("[debug] aikias.js time click");
        $( "input.time" ).prop("disabled", !this.checked);
        $( "#period" ).prop("checked", !this.checked);
        $( "input.period" ).prop("disabled", this.checked);
    });

    $( ".checkequipment" ).hide()

/*
    $( "#submitbtn" ).click(function() {
        console.log("[debug] aikias.js submit click");
        var cnt = 0;
        if ($( "#projectorkey" ).prop("checked")) { cnt++; }
        if ($( "#pcwin" ).prop("checked")) { cnt++; }
        if ($( "#pcmac" ).prop("checked")) { cnt++; }
        if ($( "#extdvd" ).prop("checked")) { cnt++; }
        if ($( "#dvd" ).prop("checked")) { cnt++; }
        if ($( "#bluray" ).prop("checked")) { cnt++; }
        if ($( "#ohc" ).prop("checked")) { cnt++; }
        if ($( "#others" ).prop("checked")) { cnt++; }
        if (cnt > 0) {
            console.log("[debug] aikias.js submit click return true cnt: " + cnt);
            $( ".checkequipment" ).hide()
            return true;
        } else {
            console.log("[debug] aikias.js submit click return false cnt: " + cnt);
            $( ".checkequipment" ).show()
            return false;
        }
    });
*/

});

