# -*- coding: utf-8 -*-
"""
    gaemailapp.mail_as.schedule.py
    ~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    :copyright: (c) 2018 AIkias.com. All Rights Reserved.
"""
import cgi
import logging
import webapp2
import datetime

from model import ReqEquipment
from config import JINJA_ENVIRONMENT, DOMAIN_NAME, ADMIN_EMAIL, STAFF_EMAILS
from google.appengine.api import users

class ScheduleHandler(webapp2.RequestHandler):

    def get(self):
        logging.info("[debug] schedule.py class ScheduleHandler get()")
        logout_url = ''
        toemail = ''
        user = users.get_current_user()
        if user:
            toemail = user.email()
            logging.info("[debug] toemail: %r" % (toemail))
            logout_url = users.create_logout_url('/')
            staff_flg = toemail in STAFF_EMAILS
            if not (toemail.endswith(DOMAIN_NAME) or toemail == ADMIN_EMAIL or staff_flg):
                logging.info("[debug] class ScheduleHandler get() logout toemail: %r" % (toemail))
                return self.redirect(logout_url)

#            qdate_dt = datetime.date.today()
            DIFF_JST_FROM_UTC = 9
            qdate_dt = (datetime.datetime.utcnow() + datetime.timedelta(hours=DIFF_JST_FROM_UTC)).date()
            logging.info("[debug] qdate_dt: %r" %(qdate_dt))
            reqEquipments = ReqEquipment.query().filter(ReqEquipment.sdate == qdate_dt).order(ReqEquipment.room).order(ReqEquipment.stime).fetch()

            template_values = {
                'staff_flg': staff_flg,
                'logout_url': logout_url,
                'reqEquipments': reqEquipments,
                'qdate': qdate_dt,
            }
            template = JINJA_ENVIRONMENT.get_template('schedule.html')
            self.response.write(template.render(template_values))



    def post(self):
        logging.info("[debug] schedule.py class ScheduleHandler post()")
        logout_url = ''
        toemail = ''
        user = users.get_current_user()
        if user:
            toemail = user.email()
            logging.info("[debug] toemail: %r" % (toemail))
            logout_url = users.create_logout_url('/')
            staff_flg = toemail in STAFF_EMAILS
            if not (toemail.endswith(DOMAIN_NAME) or toemail == ADMIN_EMAIL or staff_flg):
                logging.info("[debug] class ScheduleHandler get() logout toemail: %r" % (toemail))
                return self.redirect(logout_url)

            qdate = self.request.get('qdate')
            logging.info("[debug] qdate=%r" %(qdate))

            reqEquipments = ReqEquipment.query().filter(ReqEquipment.sdate == datetime.datetime.strptime(qdate, '%Y-%m-%d').date()).order(ReqEquipment.room).order(ReqEquipment.stime).fetch()

            template_values = {
                'staff_flg': staff_flg,
                'logout_url': logout_url,
                'reqEquipments': reqEquipments,
                'qdate': qdate,
            }
            template = JINJA_ENVIRONMENT.get_template('schedule.html')
            self.response.write(template.render(template_values))

