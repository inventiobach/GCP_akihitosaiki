# -*- coding: utf-8 -*-
"""
    gaemailapp.mail_as.list.py
    ~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    :copyright: (c) 2018 AIkias.com. All Rights Reserved.
"""
import cgi
import logging
import webapp2
import datetime

from model import ReqEquipment
from config import JINJA_ENVIRONMENT, DOMAIN_NAME, ADMIN_EMAIL, STAFF_EMAILS
from google.appengine.api import users


class ListHandler(webapp2.RequestHandler):

    def get(self):
        logging.info("[debug] list.py class ListHandler get()")
        logout_url = ''
        toemail = ''
        user = users.get_current_user()
        if user:
            toemail = user.email()
            logging.info("[debug] toemail: %r" % (toemail))
            logout_url = users.create_logout_url('/')
            staff_flg = toemail in STAFF_EMAILS
            if not (toemail.endswith(DOMAIN_NAME) or toemail == ADMIN_EMAIL or staff_flg):
                logging.info("[debug] class ListHandler get() logout toemail: %r" % (toemail))
                return self.redirect(logout_url)

            reqEquipments = ReqEquipment.query().filter(ReqEquipment.toemail == toemail).order(ReqEquipment.sdate).order(ReqEquipment.room).order(ReqEquipment.stime).fetch()

            template_values = {
                'staff_flg': staff_flg,
                'logout_url': logout_url,
                'reqEquipments': reqEquipments,
            }
            template = JINJA_ENVIRONMENT.get_template('list.html')
            self.response.write(template.render(template_values))
