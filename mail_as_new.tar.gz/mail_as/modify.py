# -*- coding: utf-8 -*-
"""
    gaemailapp.mail_as.modify.py
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    :copyright: (c) 2018 AIkias.com. All Rights Reserved.
"""
import os
import jinja2
import cgi
import logging
import webapp2
import datetime

from model import ReqEquipment
from config import opt_rooms, equips, JINJA_ENVIRONMENT, DOMAIN_NAME, ADMIN_EMAIL, STAFF_EMAILS
from google.appengine.api import users

class ModifyHandler(webapp2.RequestHandler):

    def get(self):
        logging.info("[debug] modify.py class ModifyHandler get()")
        logout_url = ''
        toemail = ''
        user = users.get_current_user()
        if user:
            toemail = user.email()
            logging.info("[debug] toemail: %r" % (toemail))
            logout_url = users.create_logout_url('/')
            staff_flg = toemail in STAFF_EMAILS
            if not (toemail.endswith(DOMAIN_NAME) or toemail == ADMIN_EMAIL or staff_flg):
                logging.info("[debug] class ModifyHandler get() logout toemail: %r" % (toemail))
                return self.redirect(logout_url)

            qid = int(self.request.GET['id'])
            sdate = self.request.GET['sdate']
            sfrom = self.request.GET['from']
            logging.info("[debug] id: %r sdate: %r" % (qid, sdate))
            reqEquipments = ReqEquipment.query().filter(ReqEquipment.sdate == datetime.datetime.strptime(sdate, '%Y-%m-%d').date()).filter(ReqEquipment.id == qid).fetch()
            reqEquipment = reqEquipments[0]

            template_values = {
                'staff_flg': staff_flg,
                'logout_url': logout_url,
                'id': str(reqEquipment.id),
                'opt_rooms': opt_rooms,
                'room': reqEquipment.room,
                'org_sdate': reqEquipment.sdate,
                'sdate': reqEquipment.sdate,
                'repeat': reqEquipment.repeat,
                'stime': reqEquipment.stime.isoformat()[:5],
                'etime': reqEquipment.etime.isoformat()[:5],
                'equips': equips,
                'equipment': reqEquipment.equipment,
                'purpose': reqEquipment.purpose,
                'instructor': reqEquipment.instructor,
                'applicant': reqEquipment.applicant,
                'email': reqEquipment.email,
                'notes': reqEquipment.notes,
                'sfrom': sfrom,
            }
            template = JINJA_ENVIRONMENT.get_template('modify.html')
            self.response.write(template.render(template_values))

    def post(self):
        logging.info("[debug] modify.py class ModifyHandler post()")
        qid = int(self.request.get('id'))
        qdate = self.request.get('org_sdate')
        sfrom = self.request.get('sfrom')

#        date = self.request.get('date')
#        notes = self.request.get('notes')

        room = self.request.get('room', 'Others')
        sdate = self.request.get('date')
        sdate_dt = datetime.datetime.strptime(sdate, '%Y-%m-%d').date()

        stime = self.request.get('stime')
        etime = self.request.get('etime')
        stime_dt = datetime.datetime.strptime(stime, '%H:%M').time()
        etime_dt = datetime.datetime.strptime(etime, '%H:%M').time()

        equipa = []
        if self.request.get('pcwin'):
            equipa.append('PC (Windows)')
        if self.request.get('pcmac'):
            equipa.append('PC (Mac)')
        if self.request.get('extdvd'):
            equipa.append('External DVD for PC')
        if self.request.get('dvd'):
            equipa.append('DVD (CPRM and Region Free compatible)')
        if self.request.get('bluray'):
            equipa.append('Blu-ray')
        if self.request.get('ohc'):
            equipa.append('OHC')
            
        if len(equipa) == 0:
            equipment = ''
        else:
            equipment = (', ').join(equipa)

        purpose = self.request.get('purpose')
        instructor = self.request.get('instructor')
        applicant = self.request.get('applicant')
        email = self.request.get('email')
        notes = self.request.get('notes')

        register_num = ''

        logging.info("[debug] %r, %r, %r, %r, %r, %r, %r, %r, %r, %r, %r, %r"
                        % (qid, qdate, room, sdate_dt, stime_dt, etime_dt,
                           equipment, purpose, instructor, applicant, email, notes))

        reqEquipments = ReqEquipment.query().filter(ReqEquipment.sdate == datetime.datetime.strptime(qdate, '%Y-%m-%d').date()).filter(ReqEquipment.id == qid).fetch()
        reqEquipment = reqEquipments[0]
        logging.info("[debug] qdate=%r qid=%r" %(qdate, qid))
#        logging.info("[debug] reqEquipment=%r" %(reqEquipment))

        reqEquipment.room = room
        reqEquipment.equipment = equipment
        reqEquipment.sdate = sdate_dt
        reqEquipment.stime = stime_dt
        reqEquipment.etime = etime_dt
        reqEquipment.purpose = purpose
        reqEquipment.instructor = instructor
        reqEquipment.register_num = register_num
        reqEquipment.applicant = applicant
        reqEquipment.email = email
        reqEquipment.notes = notes

        logging.info("[debug] reqEquipment.put() for update")
        reqEquipment_key = reqEquipment.put()
      
        if sfrom == 'list':
            return self.redirect('/list')
        else:
            return self.redirect('/edit?id=%s' % (str(qid)))
      
