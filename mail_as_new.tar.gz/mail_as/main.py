# -*- coding: utf-8 -*-
"""

    gaemailapp.mail_as.main.py
    ~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    :copyright: (c) 2018 AIkias.com. All Rights Reserved.
"""
import webapp2
import datetime

from asform import FormPage
from list import ListHandler
from edit import EditHandler
from asprint import PrintHandler
from modify import ModifyHandler
from delete import DeleteHandler
from schedule import ScheduleHandler

app = webapp2.WSGIApplication([
    ('/', FormPage),
    ('/list', ListHandler),
    ('/edit', EditHandler),
    ('/asprint', PrintHandler),
    ('/modify', ModifyHandler),
    ('/delete', DeleteHandler),
    ('/schedule', ScheduleHandler),
], debug=True)
