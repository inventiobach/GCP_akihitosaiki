# -*- coding: utf-8 -*-
"""
    gaemailapp.mail_as.model.py
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    :copyright: (c) 2018 AIkias.com. All Rights Reserved.
"""
from google.appengine.ext import ndb

class ReqEquipment(ndb.Model):

    date = ndb.DateTimeProperty(auto_now_add=True)
    toemail = ndb.StringProperty()
    id = ndb.IntegerProperty()
    room = ndb.StringProperty()
    equipment = ndb.StringProperty()
    repeat = ndb.StringProperty()
    sdate = ndb.DateProperty()
    stime = ndb.TimeProperty()
    etime = ndb.TimeProperty()
    purpose = ndb.StringProperty()
    instructor = ndb.StringProperty()
    register_num = ndb.StringProperty()
    applicant = ndb.StringProperty()
    email = ndb.StringProperty()
    notes = ndb.StringProperty()
    