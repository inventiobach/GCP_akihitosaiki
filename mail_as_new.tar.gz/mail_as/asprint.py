# -*- coding: utf-8 -*-
"""
    gaemailapp.mail_as.asprint.py
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    :copyright: (c) 2018 AIkias.com. All Rights Reserved.
"""
import cgi
import logging
import webapp2
import datetime
from model import ReqEquipment

from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.lib.units import cm

from cStringIO import StringIO
from config import JINJA_ENVIRONMENT, DOMAIN_NAME, ADMIN_EMAIL, STAFF_EMAILS
from google.appengine.api import users

class PrintHandler(webapp2.RequestHandler):

    def get(self):
        logging.info("[debug] asprint.py class PrintHandler get()")
        logout_url = ''
        toemail = ''
        user = users.get_current_user()
        if user:
            toemail = user.email()
            logging.info("[debug] toemail: %r" % (toemail))
            logout_url = users.create_logout_url('/')
            staff_flg = toemail in STAFF_EMAILS
            if not (toemail == ADMIN_EMAIL or staff_flg):
                logging.info("[debug] class PrintHandler get() logout toemail: %r" % (toemail))
                return self.redirect(logout_url)
        
            template_values = {
                'staff_flg': staff_flg,
                'logout_url': logout_url,
            }
            template = JINJA_ENVIRONMENT.get_template('asprint.html')
            self.response.write(template.render(template_values))
        
    def post(self):
        qdate = self.request.get('qdate')
        if self.request.get('qid'):
            qid = int(self.request.get('qid'))
            reqEquipments = ReqEquipment.query().filter(ReqEquipment.sdate == datetime.datetime.strptime(qdate, '%Y-%m-%d').date()).filter(ReqEquipment.id == qid).order(ReqEquipment.room).order(ReqEquipment.stime).fetch()
        else:
            qid = 0
            reqEquipments = ReqEquipment.query().filter(ReqEquipment.sdate == datetime.datetime.strptime(qdate, '%Y-%m-%d').date()).order(ReqEquipment.room).order(ReqEquipment.stime).fetch()
        logging.info("[debug] Staff post() qdate=%r qid=%r" %(qdate, qid))
        logging.info("[debug] Staff post() reqEquipments=%r" %(reqEquipments))

        equip = ['PC (Windows)', 'PC (Mac)', 'External DVD for PC', 'DVD (CPRM and Region Free compatible)', 'Blu-ray', 'OHC']
        
        data = StringIO()

        cv = canvas.Canvas(data)
        cv.saveState()
 
        cv.setAuthor('AIkias.com')
        cv.setTitle('Request for Equipment')
        cv.setSubject('Request for Equipment')
 
        xm = 29.7*cm
        xc = xm/2
        ym = 21.0*cm
        yc = ym/2
        wk = 0.3*cm

        cv.setPageSize((xm, ym))
        cv.setLineWidth(1)
        po = [[wk,ym-wk], [xc+wk,ym-wk], [wk,yc-wk], [xc+wk,yc-wk]]
        pdfmetrics.registerFont(UnicodeCIDFont('HeiseiKakuGo-W5'))

        cv.line(0, yc, xm, yc)
        cv.line(xc, 0, xc, ym)

        n = 0
        for reqEquipment in reqEquipments:
            logging.info("[debug] Staff post() reqEquipment.sdate: %r, id: %r, notes: %r" % (reqEquipment.sdate, reqEquipment.id, reqEquipment.notes))
            
            cv.setFont('HeiseiKakuGo-W5', 12)
            cv.drawString(po[n][0], po[n][1]-0.5*cm, 'Instructor:')
            cv.setFont('HeiseiKakuGo-W5', 33)
            cv.drawString(po[n][0], po[n][1]-1.6*cm, '%s' % (reqEquipment.instructor[:20]))

            cv.setFont('HeiseiKakuGo-W5', 15)
            cv.drawString(po[n][0], po[n][1]-2.5*cm, 'room:')
            cv.setFont('HeiseiKakuGo-W5', 24)
            cv.drawString(po[n][0]+3*cm, po[n][1]-2.5*cm, '%s' % (reqEquipment.room))

            cv.setFont('HeiseiKakuGo-W5', 15)
            cv.drawString(po[n][0], po[n][1]-3.3*cm, 'date:')
            cv.setFont('HeiseiKakuGo-W5', 20)
            cv.drawString(po[n][0]+3*cm, po[n][1]-3.3*cm, '%s  (%s)' % (reqEquipment.sdate.isoformat(), reqEquipment.repeat))

            cv.setFont('HeiseiKakuGo-W5', 15)
            cv.drawString(po[n][0], po[n][1]-4.1*cm, 'time:')
            cv.setFont('HeiseiKakuGo-W5', 20)
            cv.drawString(po[n][0]+3*cm, po[n][1]-4.1*cm, '%s - %s' % (reqEquipment.stime.isoformat()[:5], reqEquipment.etime.isoformat()[:5]))

            cv.setFont('HeiseiKakuGo-W5', 15)
            cv.drawString(po[n][0], po[n][1]-4.8*cm, 'ID:')
            cv.drawString(po[n][0]+3*cm, po[n][1]-4.8*cm, '%s' % (reqEquipment.id))

            cv.setFont('HeiseiKakuGo-W5', 20)
            
            re = reqEquipment.equipment.split(', ')
            if equip[0] in re:
                cv.drawString(po[n][0], po[n][1]-5.7*cm, '[  ] PC (Windows)')
            if equip[1] in re:
                cv.drawString(po[n][0], po[n][1]-6.7*cm, '[  ] PC (Mac)')
            if equip[2] in re:
                cv.drawString(po[n][0], po[n][1]-7.7*cm, '[  ] External DVD')
            if equip[3] in re:
                cv.drawString(po[n][0]+xc/2, po[n][1]-5.7*cm, '[  ] DVD')
            if equip[4] in re:
                cv.drawString(po[n][0]+xc/2, po[n][1]-6.7*cm, '[  ] Blu-ray')
            if equip[5] in re:
                cv.drawString(po[n][0]+xc/2, po[n][1]-7.7*cm, '[  ] OHC')

            cv.setFont('HeiseiKakuGo-W5', 15)
            cv.drawString(po[n][0]+xc-2.6*cm, po[n][1]-6.4*cm, 's:')
            cv.line(po[n][0]+xc-2.6*cm, po[n][1]-6.6*cm, po[n][0]+xc-0.6*cm, po[n][1]-6.6*cm,)
            cv.drawString(po[n][0]+xc-2.6*cm, po[n][1]-7.7*cm, 'r:')
            cv.line(po[n][0]+xc-2.6*cm, po[n][1]-7.9*cm, po[n][0]+xc-0.6*cm, po[n][1]-7.9*cm,)

            cv.setFont('HeiseiKakuGo-W5', 10)
            cv.drawString(po[n][0], po[n][1]-8.4*cm, 'Notes:')
            cv.setFont('HeiseiKakuGo-W5', 10)
            cv.drawString(po[n][0], po[n][1]-8.9*cm, '%s' % (reqEquipment.notes[:40]))
            cv.drawString(po[n][0], po[n][1]-9.4*cm, '%s' % (reqEquipment.notes[40:80]))
            cv.drawString(po[n][0], po[n][1]-9.9*cm, '%s' % (reqEquipment.notes[80:120]))

            n += 1
            if n == 4:
                cv.showPage()
                cv.line(0, yc, xm, yc)
                cv.line(xc, 0, xc, ym)
                n = 0
            
        if n != 0:
            cv.showPage()
        cv.save()
	
        self.response.headers['Content-Type'] = 'application/pdf'
        self.response.out.write(data.getvalue())

