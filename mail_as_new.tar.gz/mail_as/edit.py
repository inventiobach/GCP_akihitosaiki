# -*- coding: utf-8 -*-
"""
    gaemailapp.mail_as.edit.py
    ~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    :copyright: (c) 2018 AIkias.com. All Rights Reserved.
"""
import cgi
import logging
import webapp2
import datetime

from model import ReqEquipment
from config import JINJA_ENVIRONMENT, DOMAIN_NAME, ADMIN_EMAIL, STAFF_EMAILS
from google.appengine.api import users

class EditHandler(webapp2.RequestHandler):

    def get(self):
        logging.info("[debug] edit.py class EditHandler get()")
        logout_url = ''
        toemail = ''
        user = users.get_current_user()
        if user:
            toemail = user.email()
            logging.info("[debug] toemail: %r" % (toemail))
            logout_url = users.create_logout_url('/')
            staff_flg = toemail in STAFF_EMAILS
            if not (toemail == ADMIN_EMAIL or staff_flg):
                logging.info("[debug] class EditHandler get() logout toemail: %r" % (toemail))
                return self.redirect(logout_url)
 
            try:
                qid = int(self.request.GET['id'])
            except:
                qid = 0
            logging.info("[debug] qid: %r" % (qid))

            if qid != 0:
                reqEquipments = ReqEquipment.query().filter(ReqEquipment.id == qid).order(ReqEquipment.sdate).order(ReqEquipment.room).order(ReqEquipment.stime).fetch()
            else:
                reqEquipments = []
                                        
            template_values = {
                'staff_flg': staff_flg,
                'logout_url': logout_url,
                'qid': str(qid),
                'reqEquipments': reqEquipments,
            }
            template = JINJA_ENVIRONMENT.get_template('edit.html')
            self.response.write(template.render(template_values))


    def post(self):
        logging.info("[debug] edit.py class EditHandler post()")
        logging.info("[debug] qid: %r" % (self.request.get('qid')))

        logout_url = ''
        toemail = ''
        user = users.get_current_user()
        if user:
            toemail = user.email()
            logging.info("[debug] toemail: %r" % (toemail))
            logout_url = users.create_logout_url('/')
            staff_flg = toemail in STAFF_EMAILS
            if not (toemail.endswith(DOMAIN_NAME) or toemail == ADMIN_EMAIL or staff_flg):
                logging.info("[debug] class EditHandler post() logout toemail: %r" % (toemail))
                return self.redirect(logout_url)

            if self.request.get('qid'):
                qid = int(self.request.get('qid'))
                reqEquipments = ReqEquipment.query().filter(ReqEquipment.id == qid).order(ReqEquipment.sdate).order(ReqEquipment.room).order(ReqEquipment.stime).fetch()
            else:
                return self.redirect('/edit')

            logging.info("[debug] qid=%r" %(qid))

            template_values = {
                'staff_flg': staff_flg,
                'logout_url': logout_url,
                'qid': str(qid),
                'reqEquipments': reqEquipments,
            }
            template = JINJA_ENVIRONMENT.get_template('edit.html')
            self.response.write(template.render(template_values))

