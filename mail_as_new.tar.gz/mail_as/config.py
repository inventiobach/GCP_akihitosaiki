# -*- coding: utf-8 -*-
"""
    gaemailapp.mail_as.model.py
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    :copyright: (c) 2018 AIkias.com. All Rights Reserved.
"""
import os
import jinja2
import datetime

# edate_dt = datetime.date(2019, 2, 26)
# edate_dt = datetime.date(2019, 6, 18)
# edate_dt = datetime.date(2019, 11, 14)
# edate_dt = datetime.date(2020, 2, 26)
edate_dt = datetime.date(2020, 6, 18)


ps2dt = [(datetime.datetime(1900,1,1,8,50), datetime.datetime(1900,1,1,10,10)),
         (datetime.datetime(1900,1,1,10,10), datetime.datetime(1900,1,1,11,20)),
         (datetime.datetime(1900,1,1,11,30), datetime.datetime(1900,1,1,12,40)), 
         (datetime.datetime(1900,1,1,13,15), datetime.datetime(1900,1,1,15,00)), 
         (datetime.datetime(1900,1,1,13,50), datetime.datetime(1900,1,1,15,00)), 
         (datetime.datetime(1900,1,1,15,10), datetime.datetime(1900,1,1,16,20)), 
         (datetime.datetime(1900,1,1,16,30), datetime.datetime(1900,1,1,17,40)), 
         (datetime.datetime(1900,1,1,17,50), datetime.datetime(1900,1,1,19,00)),
         (datetime.datetime(1900,1,1,19,00), datetime.datetime(1900,1,1,20,20))]

periodchr = ['1', '2', '3', '14', '4', '5', '6', '7', '8']
opt_rooms = ['Others', 'H-102', 'H-104', 'H-106', 'H-107', 'H-108', 'H-115', 'H-116', 'H-151']
equips = [("pcwin", "PC (Windows)"), ("pcmac", "PC (Mac)"), ("extdvd", "External DVD for PC"),
          ("dvd", "DVD (CPRM and Region Free compatible)"), ("bluray", "Blu-ray"), ("ohc", "OHC")]

JINJA_ENVIRONMENT = jinja2.Environment(
    loader=jinja2.FileSystemLoader(os.path.join(os.path.dirname(__file__), 'templates')),
    extensions=['jinja2.ext.autoescape'],
    autoescape=True)

DOMAIN_NAME = '@icu.ac.jp'
ADMIN_EMAIL = 'akihito.saiki@gmail.com'
STAFF_EMAILS = ['akihito.saiki@gmail.com', 'saiakihito@icu.ac.jp']
