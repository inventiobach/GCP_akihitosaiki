# -*- coding: utf-8 -*-
"""
    gaemailapp.mail_as.handle_incoming_email.py
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    :copyright: (c) 2018 AIkias.com. All Rights Reserved.
"""
import webapp2
import logging
from google.appengine.ext.webapp.mail_handlers import InboundMailHandler

import datetime
from model import ReqEquipment
from config import edate_dt, ps2dt, periodchr

prefix = ['ID:', 'Room: ', 'Equipment: ', 'Repeat: ',
          'First_Day: ', 'Period: ', 'Time: ', 'Purpose: ',
          'Instructor: ', 'Register_Number: ', 'Applicant: ',
          'Email: ', 'Notes: ']

dbprefix = ['ID:', 'Room: ', 'Equipment: ', 'Repeat: ',
          'First_Day: ', 'stime: ', 'etime: ', 'Purpose: ',
          'Instructor: ', 'Register_Number: ', 'Applicant: ',
          'Email: ', 'Notes: ']

dictprefix = {'ID:': '', 'Room: ': '', 'Equipment: ': '', 'Repeat: ': '',
           'First_Day: ': '', 'stime: ': '', 'etime: ': '', 'Purpose: ': '',
           'Instructor: ': '', 'Register_Number: ': '', 'Applicant: ': '',
           'Email: ': '', 'Notes: ': ''}


class LogSenderHandler(InboundMailHandler):

    def receive(self, mail_message):
#        logging.info("[debug] handle_incoming_email.py class LogSenderHandler recieve()")

        toemail = mail_message.to.split(', ')[0]
        logging.info("[debug] Recieved a message from: %r to: %r" % (mail_message.sender, toemail))

        plaintext_bodies = mail_message.bodies('text/plain')
#        html_bodies = mail_message.bodies('text/html')
        
#        for content_type, body in html_bodies:
#            decoded_html = body.decode()            
#            logging.info("[debug] Html body of length %d." % len(decoded_html))
#            logging.info("[debug] Html body: %r " % (decoded_html))
            
        for content_type, body in plaintext_bodies:
            plaintext = body.decode()
            logging.info("[debug] Plain text body of length %d." % len(plaintext))
            logging.info("[debug] Plain text body: %r" % (plaintext))

            for pre in dbprefix:
                dictprefix[pre] = ""

            for line in plaintext.splitlines():
#                print line
                for pre in prefix:
                    if line.startswith(pre):
                        if pre == 'Period: ':
                            lp = line[len(pre):]
                            lp1 = lp.split(' ')
#                            print pre + lperise[0] + ' - ' + lperise[2]
                            stime_dt = ps2dt[periodchr.index(lp1[0])][0].time()
                            etime_dt = ps2dt[periodchr.index(lp1[2])][1].time()
#                            print 'period stime: %r, period etime: %r' % (stime_dt, etime_dt)
            	            dictprefix['stime: '] = stime_dt
            	            dictprefix['etime: '] = etime_dt
                        elif pre == 'Time: ':
                            lp = line[len(pre):]
                            lp1 = lp.split(' ')
#                            print pre + ltimese[0] + ' - ' + ltimese[2]
                    	    stime_dt = datetime.datetime.strptime(lp1[0], '%H:%M').time()
            	            etime_dt = datetime.datetime.strptime(lp1[2], '%H:%M').time()
#                            print 'period stime: %r, period etime: %r' % (stime_dt, etime_dt)
            	            dictprefix['stime: '] = stime_dt
            	            dictprefix['etime: '] = etime_dt
                        else:
                            dictprefix[pre] = line[len(pre):]
#                            print "start: " + pre + "=" + dictprefix[pre]
#            for pre in dbprefix:
#                logging.info("dictprefix[ %s ] = %r" % (pre, dictprefix[pre]))
#                dictprefix[pre] = ""
            if dictprefix['ID:']:
                logging.info("db toemail=%r" % (toemail))
                
                id = int(dictprefix['ID:']);
                logging.info("db id=%r" % (id))

                room = dictprefix['Room: '];
                logging.info("db room=%r" % (room))

                equipment = dictprefix['Equipment: '];
                logging.info("db equipment=%r" % (equipment))

                repeat = dictprefix['Repeat: '];
                logging.info("db repeat=%r" % (repeat))

                first_day = dictprefix['First_Day: '];
                sdate_dt = datetime.datetime.strptime(first_day, '%Y-%m-%d').date()
                logging.info("db sdate_dt=%r" % (sdate_dt))

                stime = dictprefix['stime: '];
                logging.info("db stime=%r" % (stime))

                etime = dictprefix['etime: '];
                logging.info("db etime=%r" % (etime))

                purpose = dictprefix['Purpose: '];
                logging.info("db purpose=%r" % (purpose))

                instructor = dictprefix['Instructor: '];
                logging.info("db instructor=%r" % (instructor))

                register_num = dictprefix['Register_Number: '];
                logging.info("db register_num=%r" % (register_num))

                applicant = dictprefix['Applicant: '];
                logging.info("db applicant=%r" % (applicant))

                email = dictprefix['Email: '];
                logging.info("db email=%r" % (email))

                notes = dictprefix['Notes: '];
                logging.info("db notes=%r" % (notes))
                
                logging.info("reqEquipment = ReqEquipment()")
                reqEquipment = ReqEquipment(toemail=toemail, id=id, room=room, equipment=equipment,
                                            repeat=repeat, sdate=sdate_dt, stime=stime, etime=etime,
                                            purpose=purpose, instructor=instructor, register_num=register_num,
                                            applicant=applicant, email=email, notes=notes)
                logging.info("reqEquipment.put()")
                reqEquipment.put()
                
                if repeat == 'EveryWeek':
                    for i in range(1, 15):
                        sdate_dti = sdate_dt + datetime.timedelta(weeks=i)
                        if sdate_dti < edate_dt:
                            logging.info("EveryWeek id=%r sdate_dti=%r" % (id, sdate_dti))
                            logging.info("reqEquipment = ReqEquipment() repeat")
                            reqEquipment = ReqEquipment(toemail=toemail, id=id, room=room, equipment=equipment,
                                                        repeat=repeat, sdate=sdate_dti, stime=stime, etime=etime,
                                                        purpose=purpose, instructor=instructor, register_num=register_num,
                                                        applicant=applicant, email=email, notes=notes)
                            logging.info("reqEquipment.put() repeat")
                            reqEquipment.put()


app = webapp2.WSGIApplication([LogSenderHandler.mapping()], debug=True)
