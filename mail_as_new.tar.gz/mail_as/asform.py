# -*- coding: utf-8 -*-
"""

    gaemailapp.mail_as.asform.py
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    :copyright: (c) 2018 AIkias.com. All Rights Reserved.
"""
import os
import jinja2
import webapp2
import datetime
import logging

from model import ReqEquipment
from config import edate_dt, ps2dt, periodchr, opt_rooms, equips, JINJA_ENVIRONMENT, DOMAIN_NAME, ADMIN_EMAIL, STAFF_EMAILS
from google.appengine.api import users
from google.appengine.api import mail


class FormPage(webapp2.RequestHandler):

    def get(self):
        logging.info("[debug] form.py class FormPage get()")
        logout_url = ''
        toemail = ''
        user = users.get_current_user()
        if user:
            toemail = user.email()
            logging.info("[debug] toemail: %r" % (toemail))
            logout_url = users.create_logout_url('/')
            staff_flg = toemail in STAFF_EMAILS
            if not (toemail.endswith(DOMAIN_NAME) or toemail == ADMIN_EMAIL or staff_flg):
                logging.info("[debug] class FormPage get() logout toemail: %r" % (toemail))
                return self.redirect(logout_url)
                
            template_values = {
                'staff_flg': staff_flg,
                'logout_url': logout_url,
                'opt_rooms': opt_rooms,
                'equips': equips,
            }

            template = JINJA_ENVIRONMENT.get_template('asform.html')
            self.response.write(template.render(template_values))
        
    def post(self):
        logging.info("[debug] form.py class FormPage post()")

        toemail = ''
        user = users.get_current_user()
        if user:
            toemail = user.email()
        logging.info("[debug] toemail: %r" % (toemail))
        
        room = self.request.get('room', 'Others')
        sdate = self.request.get('date')
        sdate_dt = datetime.datetime.strptime(sdate, '%Y-%m-%d').date()
        repeat = self.request.get('repeat')
        
        period = self.request.get('period')
        speriod = self.request.get('speriod')
        eperiod = self.request.get('eperiod')

        if period:
            stime_dt = ps2dt[periodchr.index(speriod)][0].time()
            etime_dt = ps2dt[periodchr.index(eperiod)][1].time()

        ptime = self.request.get('time')
        stime = self.request.get('stime')
        etime = self.request.get('etime')
#        logging.info("[debug] stime: %r, etime: %r " % (stime, etime))
               
        if ptime:
            stime_dt = datetime.datetime.strptime(stime, '%H:%M').time()
            etime_dt = datetime.datetime.strptime(etime, '%H:%M').time()
            
        
#        equip = self.request.GET.getall('equip')
#        projectorkey = self.request.get('projectorkey')
#        if not projectorkey:
#            projectorkey = "no check"
#PC (Windows)', 'PC (Mac)', 'External DVD for PC', 'DVD (CPRM and Region Free compatible)', 'Blu-ray', 'OHC'
        equipa = []
        if self.request.get('pcwin'):
            equipa.append('PC (Windows)')
        if self.request.get('pcmac'):
            equipa.append('PC (Mac)')
        if self.request.get('extdvd'):
            equipa.append('External DVD for PC')
        if self.request.get('dvd'):
            equipa.append('DVD (CPRM and Region Free compatible)')
        if self.request.get('bluray'):
            equipa.append('Blu-ray')
        if self.request.get('ohc'):
            equipa.append('OHC')
            
        if len(equipa) == 0:
            equipment = ''
        else:
            equipment = (', ').join(equipa)

        purpose = self.request.get('purpose')
        instructor = self.request.get('instructor')
        applicant = self.request.get('applicant')
        email = self.request.get('email')
        notes = self.request.get('notes')

        register_num = ''

        logging.info("[debug] form.py class FormPage post() room: %r, %r, %r, %r, %r, %r, %r, %r, %r, %r, %r"
                        % (room, sdate_dt, repeat, stime_dt, etime_dt,
                           equipment, purpose, instructor, applicant, email, notes))

        logging.info("reqEquipment = ReqEquipment()")
        reqEquipment = ReqEquipment(toemail=toemail, id=1L, room=room, equipment=equipment,
                                    repeat=repeat, sdate=sdate_dt, stime=stime_dt, etime=etime_dt,
                                    purpose=purpose, instructor=instructor, register_num=register_num,
                                    applicant=applicant, email=email, notes=notes)
        logging.info("reqEquipment.put()")
        reqEquipment_key = reqEquipment.put()

        reqEquipment = reqEquipment_key.get()
        new_id = reqEquipment_key.id()
        reqEquipment.id = new_id
#        sdate = reqEquipment.sdate
        logging.info("[debug] update id reqEquipment_key = reqEquipment.put()")
        reqEquipment_key = reqEquipment.put()

        if repeat == 'EveryWeek':
            for i in range(1, 15):
                sdate_dti = sdate_dt + datetime.timedelta(weeks=i)
                if sdate_dti < edate_dt:
                    logging.info("EveryWeek id=%r sdate_dti=%r" % (new_id, sdate_dti))
                    logging.info("reqEquipment = ReqEquipment() repeat")
                    reqEquipment = ReqEquipment(toemail=toemail, id=new_id, room=room, equipment=equipment,
                                                repeat=repeat, sdate=sdate_dti, stime=stime_dt, etime=etime_dt,
                                                purpose=purpose, instructor=instructor, register_num=register_num,
                                                applicant=applicant, email=email, notes=notes)
                    logging.info("reqEquipment.put() repeat")
                    reqEquipment.put()

        message = mail.EmailMessage(
            sender="support@gaemailapp.appspotmail.com",
            subject="Equipments reservation"
        )
        
        message.to = [toemail, "inventio.bach@gmail.com"]
        message.body = """We have received your reservation.

ID:%s
Room: %s
Equipment: %s
Repeat: %s
First_Day: %s
Time: %s - %s
Purpose: %s
Instructor: %s
Register_Number: 
Applicant: %s
Email: %s
Notes: %s
""" %   (str(new_id), room, equipment, repeat, sdate_dt.isoformat(),
        stime_dt.isoformat()[:5], etime_dt.isoformat()[:5], purpose,
        instructor, applicant, email, notes)

        logging.info("[debug] message.send() body: %s" % (message.body))
       
#OK for degub#        message.send()

        return self.redirect('/list')
       
