# -*- coding: utf-8 -*-
"""
    gaemailapp.mail_as.delete.py
    ~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    :copyright: (c) 2018 AIkias.com. All Rights Reserved.
"""
import cgi
import logging
import webapp2
import datetime

from model import ReqEquipment
from config import JINJA_ENVIRONMENT, DOMAIN_NAME, ADMIN_EMAIL, STAFF_EMAILS
from google.appengine.api import users

class DeleteHandler(webapp2.RequestHandler):

    def get(self):
        logging.info("[debug] delete.py class DeleteHandler get()")
        logout_url = ''
        toemail = ''
        user = users.get_current_user()
        if user:
            toemail = user.email()
            logging.info("[debug] toemail: %r" % (toemail))
            logout_url = users.create_logout_url('/')
            staff_flg = toemail in STAFF_EMAILS
            if not (toemail.endswith(DOMAIN_NAME) or toemail == ADMIN_EMAIL or staff_flg):
                logging.info("[debug] class EditHandler get() logout toemail: %r" % (toemail))
                return self.redirect(logout_url)

            qid = int(self.request.GET['id'])
            sdate = self.request.GET['sdate']
            sfrom = self.request.GET['from']
            logging.info("[debug] id: %r sdate: %r" % (qid, sdate))
            reqEquipments = ReqEquipment.query().filter(ReqEquipment.sdate == datetime.datetime.strptime(sdate, '%Y-%m-%d').date()).filter(ReqEquipment.id == qid).fetch()
            reqEquipment = reqEquipments[0]

            template_values = {
                'staff_flg': staff_flg,
                'logout_url': logout_url,
                'sfrom': sfrom,
                'reqEquipment': reqEquipment,
            }
            template = JINJA_ENVIRONMENT.get_template('delete.html')
            self.response.write(template.render(template_values))


    def post(self):
        logging.info("[debug] delete.py class DeleteHandler post()")
        qid = int(self.request.get('qid'))
        sdate = self.request.get('sdate')
        sfrom = self.request.get('sfrom')
        logging.info("[debug] id: %r sdate: %r" % (qid, sdate))
    
        reqEquipments = ReqEquipment.query().filter(ReqEquipment.sdate == datetime.datetime.strptime(sdate, '%Y-%m-%d').date()).filter(ReqEquipment.id == qid).fetch()
        reqEquipment = reqEquipments[0]

        logging.info("[debug] reqEquipment.key.delete()")
        reqEquipment.key.delete()
        
        if sfrom == 'list':
            return self.redirect('/list')
        else:
            return self.redirect('/edit?id=%s' % (str(qid)))

